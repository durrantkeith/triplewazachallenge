# Deploy Triple Waza Challenge to Netlify

This guide will walk you through deploying your site to Netlify and connecting your custom domain **triplewazachallenge.com**.

## Quick Deploy (Recommended)

### Method 1: Drag & Drop Deploy

1. **Build the project locally**
   ```bash
   npm run build
   ```

2. **Go to Netlify Drop**
   - Visit: https://app.netlify.com/drop
   - Drag the `dist` folder onto the page
   - Wait for deployment to complete

3. **Get your site URL**
   - Netlify will give you a URL like: `https://your-site-name.netlify.app`
   - Your site is now live!

### Method 2: GitHub Integration (Best for Updates)

1. **Push your code to GitHub**
   - Create a new repository on GitHub
   - Push this project to the repository

2. **Connect to Netlify**
   - Go to: https://app.netlify.com/
   - Click "Add new site" → "Import an existing project"
   - Choose "GitHub" and select your repository
   - Configure build settings:
     - **Build command:** `npm run build`
     - **Publish directory:** `dist`
   - Click "Deploy site"

3. **Automatic deployments**
   - Every push to main branch will auto-deploy
   - No manual uploads needed!

## Connect Custom Domain: triplewazachallenge.com

### Step 1: Add Domain in Netlify

1. Go to your site in Netlify dashboard
2. Click **"Domain settings"**
3. Click **"Add custom domain"**
4. Enter: `triplewazachallenge.com`
5. Click **"Verify"** then **"Add domain"**

### Step 2: Configure DNS

You need to update DNS settings at your domain registrar (where you bought triplewazachallenge.com).

**Option A: Netlify DNS (Easiest)**
1. In Netlify, go to Domain settings → "Set up Netlify DNS"
2. Follow the wizard to migrate DNS to Netlify
3. Update nameservers at your registrar to Netlify's nameservers
4. Done! Netlify handles everything automatically

**Option B: External DNS**
Add these records at your registrar:

```
Type: A
Name: @
Value: 75.2.60.5

Type: CNAME
Name: www
Value: [your-site].netlify.app
```

Replace `[your-site]` with your actual Netlify site name.

### Step 3: Enable HTTPS

1. In Netlify Domain settings
2. Scroll to **"HTTPS"**
3. Click **"Verify DNS configuration"**
4. Wait for SSL certificate (usually 5-10 minutes)
5. Enable **"Force HTTPS"** to redirect all traffic to https://

## Environment Variables

Your site uses Supabase. Add these environment variables in Netlify:

1. Go to **Site settings** → **Environment variables**
2. Add each variable from your `.env` file:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

## Verify Deployment

Once DNS propagates (can take 1-48 hours), visit:
- https://triplewazachallenge.com
- https://www.triplewazachallenge.com

Both should work and redirect to HTTPS!

## Troubleshooting

**DNS not working?**
- Check DNS propagation: https://dnschecker.org/
- Wait up to 48 hours for global propagation
- Verify DNS records at your registrar

**Build failing?**
- Check build logs in Netlify dashboard
- Ensure all dependencies are in package.json
- Test local build: `npm run build`

**Site loads but looks broken?**
- Check environment variables are set in Netlify
- Verify Supabase credentials are correct
- Check browser console for errors

## Support

- Netlify Docs: https://docs.netlify.com/
- Netlify Support: https://www.netlify.com/support/
