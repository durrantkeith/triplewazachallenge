# Netlify Quick Start - 5 Minutes to Deploy

The fastest way to get your Triple Waza Friendship Challenge live on the internet.

---

## What You'll Need
- GitHub repository (uploaded)
- 5 minutes
- Your Supabase credentials from `.env` file

---

## Step-by-Step Deployment

### 1. Sign Up for Netlify (30 seconds)
1. Go to **https://netlify.com**
2. Click **"Sign up"**
3. Choose **"Sign up with GitHub"**
4. Authorize Netlify

### 2. Import Your Project (1 minute)
1. Click **"Add new site"** → **"Import an existing project"**
2. Click **"Deploy with GitHub"**
3. Find and select: `triple-waza-friendship-challenge`
4. Configure settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Click **"Show advanced"** → **"Add environment variables"**

### 3. Add Environment Variables (1 minute)
Click **"New variable"** and add both:

**Variable 1:**
- Key: `VITE_SUPABASE_URL`
- Value: (copy from your `.env` file)

**Variable 2:**
- Key: `VITE_SUPABASE_ANON_KEY`
- Value: (copy from your `.env` file)

### 4. Deploy! (2 minutes)
1. Click **"Deploy triple-waza-friendship-challenge"**
2. Wait for build to complete (watch the progress)
3. When you see **"Published"** with a green checkmark, you're live!

### 5. Visit Your Site (10 seconds)
Click the auto-generated URL (looks like `https://amazing-name-12345.netlify.app`)

---

## You're Done!

Your site is now live on the internet. Share the URL with anyone.

---

## Next Steps (Optional)

### Change Your Site Name
1. Go to **Site settings** → **General** → **Site details**
2. Click **"Change site name"**
3. Enter: `triple-waza-challenge` (or whatever you want)
4. Your new URL: `https://triple-waza-challenge.netlify.app`

### Add a Custom Domain
1. Go to **Domain settings** → **Add custom domain**
2. Enter your domain: `triplewaza.com`
3. Follow DNS setup instructions
4. HTTPS is automatic and free

### Enable Form Notifications
1. Go to **Site settings** → **Forms** → **Form notifications**
2. Add your email to receive submission notifications

---

## Automatic Updates

Every time you push to GitHub, Netlify automatically rebuilds and deploys your site. No extra steps needed!

---

## Troubleshooting

**Build failed?**
- Check environment variables are set correctly
- Make sure both variables have values (no quotes needed)

**Site loads but shows errors?**
- Open browser console (F12)
- Check if Supabase credentials are correct
- Verify your Supabase project is active

**Need help?**
- Check the full `DEPLOYMENT-GUIDE.md` for detailed troubleshooting
- Visit Netlify docs: https://docs.netlify.com

---

**That's it!** Your judo challenge platform is live and ready for the world.
